package com.www.lw.selenium;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

import com.webtest.core.BaseTest;
 
public class Chandao  {
	
	@Test
	public void test1() throws IOException {
		String filepath = "C:\\Users\\GAO\\Desktop\\project-exercise\\自动化测试\\冒烟测试.xlsx";
		System.setProperty("webdriver.firefox.bin", "C:\\Program Files\\Mozilla Firefox\\firefox.exe");
		WebDriver driver = new FirefoxDriver();
//		允许浏览器执行js代码
		DesiredCapabilities sCaps = new DesiredCapabilities();
		sCaps.setJavascriptEnabled(true);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		driver.get("https://2018testing.zentaopm.com/testcase-edit-249.html"); //获取URL
		
		
		driver.findElement(By.id("account")).sendKeys("liangwei2020");

		driver.findElement(By.name("password")).sendKeys("liangwei2020");
		driver.findElement(By.id("submit")).click();
		
		
//		WebElement table=driver.findElement(By.className("table table-form table-bordered"));
//		List<WebElement> rows=table.findElements(By.tagName("tr"));
//		System.out.println(rows.size());
//		下拉值页面底部
//		((JavascriptExecutor) driver).executeScript("window.scrollTo(0,document.body.scrollHeight)");
		((JavascriptExecutor) driver).executeScript("window.scrollTo(0,1000)");

		List<WebElement> list=driver.findElements(By.xpath("//i[@class='icon icon-plus']"));
		System.out.println(list.size());
//		list.get(list.size()-2).click();
		list.get(0).click();
				
//		WebElement son = driver.findElements(By.className("btn btn-step-add"))[6];\

		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		//开始获取Excel文件内的登录信息
		FileInputStream in = new FileInputStream(filepath);
		XSSFWorkbook workbook = new XSSFWorkbook(in);
		XSSFSheet sheet = workbook.getSheetAt(0);
		
		for(int j=9;j<52;j++ ) {
			XSSFRow row = sheet.getRow(j);
			
			XSSFCell cell = row.getCell(3);
			//设置单元格类型
			cell.setCellType(CellType.STRING);
			String userName = cell.getStringCellValue();
			
			XSSFCell cell2 = row.getCell(4);
			cell2.setCellType(CellType.STRING);
			String passWord =  cell2.getStringCellValue();
			
			System.out.println(userName + "," + passWord);
			in.close();
//填入数据
			driver.findElement(By.name("steps["+(j-1)+"]")).sendKeys(userName);
			driver.findElement(By.name("expects["+(j-1)+"]")).sendKeys(passWord);		
			driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			
		}
		
//		String url = driver.getCurrentUrl();
//		String result = null;
//		//写入测试结果
//		if ("https://im.qq.com/".equals(url)) {
//			result = "pass";
//		}else {
//			result = "fail";
//		};
//		XSSFCell newCell = row.createCell(2);
//		newCell.setCellValue(result);
//		FileOutputStream out = new FileOutputStream(filepath);
//		workbook.write(out);
//		workbook.close();
//		out.close();
//		driver.quit();
//		System.out.println("Down!");
	}
 
}
